import numpy as np

def calcularLU(A):
    L, U = [],[]
    # su código
    
    ###########
    return L, U


def inversaLU(L, U):
    Inv = []
    # su código
    
    ###########
    return Inv
